package AssociatedArraysExcercise;

import java.util.LinkedHashMap;
import java.util.Scanner;

public class MinerTask {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String input = keys.nextLine();

        LinkedHashMap<String, Integer> resources = new
                LinkedHashMap<>();


        while (!input.equals("stop")) {
            String resource = keys.nextLine();
            int value = Integer.parseInt(input);

            resources.put(resource, value);



        }
    }
}
