package AssociatedArraysExcercise;

public class LegendaryFarm {
    public static void main(String[] args) {
    }
}
