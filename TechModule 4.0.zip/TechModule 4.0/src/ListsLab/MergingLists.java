package ListsLab;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MergingLists {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<Integer> firstList = Arrays.stream(keys.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        List<Integer> secondList = Arrays.stream(keys.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());
        
        int minLenght = Math.min(firstList.size(), secondList.size());

        List<Integer> resultList = new ArrayList<>();


        for (int i = 0; i < minLenght; i++) {
            resultList.add(firstList.get(i));
            resultList.add(secondList.get(i));

        }

        if (firstList.size() > secondList.size()) {
            resultList.addAll(firstList
                    .subList(minLenght, firstList.size()));
        } else {
            resultList.addAll(secondList
                    .subList(minLenght, secondList.size()));

        }


        System.out.println(resultList.toString()
                .replaceAll("\\[|,|\\]", ""));
    }
}
