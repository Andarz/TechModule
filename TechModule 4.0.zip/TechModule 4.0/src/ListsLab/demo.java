package ListsLab;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String input = keys.nextLine();
        String[] numbers = input.split(" ");

        List<Double> numbersList = new ArrayList<>();

        for (String number : numbers) {
            numbersList.add(Double.parseDouble(number));
        }




    }

}
