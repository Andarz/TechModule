package ListsLab;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ListManipulationBasics {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<Integer> inputList = Arrays.stream(keys.nextLine().split("\\s+"))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        while(true) {
            String line = keys.nextLine();

            if (line.equals("end")) {
                break;
            }

            String[] command = line.split("\\s+");

            switch (command[0]) {
                case "Add":
                    int numberToAdd = Integer.parseInt(command[1]);
                    inputList.add(numberToAdd);
                    break;
                case "Remove":
                    int numberToRemove = Integer.parseInt(command[1]);
                    inputList.remove(numberToRemove);
                    break;
                case "RemoveAt":
                    int indexToRemoveAt = Integer.parseInt(command[1]);
                    inputList.remove(indexToRemoveAt);
                    break;
                case "Insert":
                    int numberToInsert = Integer.parseInt(command[1]);
                    int indexToInsert = Integer.parseInt(command[2]);
                    inputList.add(indexToInsert, numberToInsert);
                    break;
            }
        }
        System.out.println(inputList.toString()
                .replaceAll("\\[|,|\\]", "").trim());
    }
}
