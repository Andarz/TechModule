package ListsLab;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ListManipulationAdvanced {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<Integer> inputList = Arrays.stream(keys.nextLine().split("\\s+"))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        while (true) {
            String line = keys.nextLine();

            if (line.equals("end")) {
                break;
            }

            String[] command = line.split("\\s+");

            switch (command[0]) {
                case "Contains":
                    int numberDoesContain = Integer.parseInt(command[1]);
                    if (inputList.contains(numberDoesContain)) {
                        System.out.println("Yes");
                    } else {
                        System.out.println("No such number");
                    }
                    break;
                case "Print":
                    if (command[1].equals("even")) {
                        for (int i = 0; i < inputList.size(); i++) {
                            if (inputList.get(i) % 2 == 0) {
                                System.out.print(inputList.get(i) + " ");

                            }
                        }
                        System.out.println();
                    }

                    if(command[1].equals("odd")) {
                        for (int i1 = 0; i1 < inputList.size(); i1++) {
                            if (inputList.get(i1) % 2 != 0) {
                                System.out.print(inputList.get(i1) + " ");
                            }
                        }
                        System.out.println();
                    }
                    break;
                case "Get":
                    int sum = 0;
                    for (Integer anInputList : inputList) {
                        sum += anInputList;

                    }
                    System.out.println(sum);
                    break;
                case "Filter":
                    int numberToCheck = Integer.parseInt(command[2]);
                    switch (command[1]) {
                        case ">":
                            for (int i = 0; i < inputList.size(); i++) {
                                if (inputList.get(i) > numberToCheck) {
                                    System.out.print(inputList.get(i) + " ");
                                }
                            }
                            System.out.println();
                            break;
                        case "<":
                            for (int i = 0; i < inputList.size(); i++) {
                                if (inputList.get(i) < numberToCheck) {
                                    System.out.print(inputList.get(i) + " ");
                                }
                            }
                            System.out.println();
                            break;
                        case ">=":
                            for (int i = 0; i < inputList.size(); i++) {
                                if (inputList.get(i) >= numberToCheck) {
                                    System.out.print(inputList.get(i) + " ");
                                }
                            }
                            System.out.println();
                            break;
                        case "<=":
                            for (int i = 0; i < inputList.size(); i++) {
                                if (inputList.get(i) <= numberToCheck) {
                                    System.out.print(inputList.get(i) + " ");
                                }
                            }
                            break;
                    }
                }
            }
        }
    }




