package ListsLab;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class GaussTrick {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<Integer> numbers = Arrays.stream(keys.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        int initialSize = numbers.size() / 2;

        for (int i = 0; i < initialSize; i++) {
            int firstNumber = numbers.get(i);
            int index = numbers.size() - 1;
            int lastNumber = numbers.get(index);

            numbers.set(i, firstNumber + lastNumber);
            numbers.remove(index);

        }
        System.out.println(numbers.toString()
                .replaceAll("\\[|,|\\]", ""));
    }
}
