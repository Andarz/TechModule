package ListsLab;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class RemoveNegativesAndReverse {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<Integer> inputList = Arrays.stream(keys.nextLine().split("\\s+"))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        int listSize = inputList.size();

        inputList.removeIf(n -> n < 0);
        Collections.reverse(inputList);

        if (inputList.isEmpty()) {
            System.out.println("empty");
        } else {
            System.out.println(inputList.toString()
                    .replaceAll("\\[|,|\\]", ""));
        }
    }
}
