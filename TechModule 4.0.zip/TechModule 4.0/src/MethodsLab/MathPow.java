package MethodsLab;

import java.text.DecimalFormat;
import java.util.Scanner;

public class MathPow {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        double number = Double.parseDouble(keys.nextLine());
        int pow = Integer.parseInt(keys.nextLine());
        DecimalFormat format = new DecimalFormat("#.##########");
        double result = pow(number, pow);

        System.out.println(format.format(result));
    }

    static double pow(double number, int pow) {
        double result = 1;

        for (int i = 1; i <= pow; i++) {
            result *= number;

        }
        return result;
    }
}
