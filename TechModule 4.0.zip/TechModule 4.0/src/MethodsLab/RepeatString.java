package MethodsLab;

import java.util.Scanner;

public class RepeatString {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String text = keys.nextLine();
        int n = Integer.parseInt(keys.nextLine());

        System.out.println(StringRepeat(text, n));

    }
    static String StringRepeat(String text, int n) {
        String repeatString = "";
        for (int i = 0; i < n; i++) {
            repeatString += text;

        }
        return repeatString;
    }
}
