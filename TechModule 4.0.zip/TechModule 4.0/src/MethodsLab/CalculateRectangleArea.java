package MethodsLab;

import java.util.Scanner;

public class CalculateRectangleArea {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        double width = Double.parseDouble(keys.nextLine());
        double height = Double.parseDouble(keys.nextLine());

        double area = calcArea(width, height);
        System.out.printf("%.0f",area);
    }

    private static double calcArea(double width, double height) {
        return width * height;

    }
}
