package MethodsLab;

import java.util.Scanner;

public class Orders {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String product = keys.nextLine();
        int quant = Integer.parseInt(keys.nextLine());
        double price = 0;

        calculations(product, quant, price);

        }

    static void calculations(String product, int quant, double price) {
        switch (product) {
            case "coffee":
                price = 1.50;
                break;
            case "water":
                price = 1.00;
                break;
            case "coke":
                price = 1.40;
                break;
            default:
                price = 2.00;
                break;
        }
        double sum = price * quant;

        System.out.printf("%.2f", sum);
    }
}
