package MethodsExercise;

import java.util.Arrays;
import java.util.Scanner;

public class PasswordValidator {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);






    }
}
