package DATATYPESANDVARIABLESlab;

import java.util.Scanner;

public class MetersToKilometers {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int meters = Integer.parseInt(keys.nextLine());

        double kilometers = meters / 1000d;

        System.out.printf("%.2f", kilometers);
    }
}
