package DATATYPESANDVARIABLESlab;

import java.util.Scanner;

public class CenturiesToMinutes {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        byte centuries = Byte.parseByte(keys.nextLine());

        short years = (short) (centuries * 100);

    }
}
