package DATATYPESANDVARIABLESlab;

import java.util.Scanner;

public class ExactSumOfRealNumbers {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        
    }
}
