package Basic.Exercise;

import java.util.Scanner;

public class PrintAndSum {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int num1 = Integer.parseInt(keys.nextLine());
        int num2 = Integer.parseInt(keys.nextLine());

        int sum = 0;

        for (int i = num1; i <= num2 ; i++) {

            sum = sum + i;

            System.out.printf("%d ", i);
        }
        System.out.println("");
        System.out.printf("Sum: %d", sum);
    }
}
