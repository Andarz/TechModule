package Basic.Exercise;

import java.util.Scanner;

public class Vacation {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int quantity = Integer.parseInt(keys.nextLine());
        String groupType = keys.nextLine();
        String dayOfTheWeek = keys.nextLine();

        double price = 0;
        double totalPrice = 0;

        switch (dayOfTheWeek) {
            case "Friday":
                switch (groupType) {
                    case "Students":
                        price = 8.45;
                        break;
                    case "Business":
                        price = 10.90;
                        break;
                    case "Regular":
                        price = 15;
                        break;
                } break;
            case "Saturday":
                switch (groupType) {
                    case "Students":
                        price = 9.80;
                        break;
                    case "Business":
                        price = 15.60;
                        break;
                    case "Regular":
                        price = 20;
                        break;
                } break;
            case "Sunday":
                switch (groupType) {
                    case "Students":
                        price = 10.46;
                        break;
                    case "Business":
                        price = 16;
                        break;
                    case "Regular":
                        price = 22.50;
                        break;
                } break;

        }
        totalPrice = price * quantity;
        if (groupType.equals("Students") && quantity >= 30) {
            totalPrice = totalPrice - totalPrice * 0.15;
        }
        if (groupType.equals("Business") && quantity >= 100) {
            quantity = quantity - 10;
            totalPrice = price * quantity;
        }
        if (groupType.equals("Regular") && (quantity >= 10 && quantity <= 20)) {
            totalPrice = totalPrice - totalPrice * 0.05;
        }
        System.out.printf("Total price: %.2f", totalPrice);

    }
}
