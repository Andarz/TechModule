package ArraysLab;

import java.util.Scanner;

public class ReverseAnArrayOfStrings {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String[] line = keys.nextLine().split(" ");
        String[] reversed = new String[line.length];

        for (int i = 0; i < line.length; i++) {
            reversed[i] = line[line.length - 1 - i];
            System.out.print(reversed[i] + " ");

        }
    }
}
