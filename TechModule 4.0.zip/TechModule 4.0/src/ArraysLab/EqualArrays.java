package ArraysLab;

import java.util.Arrays;
import java.util.Scanner;

public class EqualArrays {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int[] arr1 = Arrays.stream(keys.nextLine().split(" "))
                .mapToInt(Integer::parseInt).toArray();
        int[] arr2 = Arrays.stream(keys.nextLine().split(" "))
                .mapToInt(Integer::parseInt).toArray();

        int sumArr = 0;

        for (int i = 0; i < arr1.length; i++) {
            sumArr += arr1[i];
            if (arr1[i] != arr2[i]) {
                System.out.println(String.format
                        ("Arrays are not identical. Found difference at %d index.", i));
                return;

            }
        }
        System.out.println(String.format
                ("Arrays are identical. Sum: %d", sumArr));
    }
}
