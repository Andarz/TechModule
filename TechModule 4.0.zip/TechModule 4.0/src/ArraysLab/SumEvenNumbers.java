package ArraysLab;

import java.util.Arrays;
import java.util.Scanner;

public class SumEvenNumbers {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int[] arr1 = Arrays.stream(keys.nextLine().split(" "))
                        .mapToInt(Integer::parseInt).toArray();
        int sum = 0;

        for (int i = 0; i < arr1.length ; i++) {
            if (arr1[i] % 2 == 0) {
                sum += arr1[i];
            }
        }
        System.out.println(sum);
    }
}
