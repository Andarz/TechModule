package ArraysLab;

import java.util.Scanner;

public class ReverseOrder {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int n = Integer.parseInt(keys.nextLine());

        int[] array = new int[n];

        for (int i = 0; i <= array.length - 1; i++) {
            int number = Integer.parseInt(keys.nextLine());
            array[i] = number;

        }

        for (int i = array.length - 1; i >= 0 ; i--) {
            System.out.print(array[i] + " ");

        }
    }
}
