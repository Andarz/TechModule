package ArraysLab;

import java.util.Scanner;

public class DayOfWeek {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int numberOfTheDay = Integer.parseInt(keys.nextLine());
        String[] daysAsString = {
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Sunday",
        };
        if (numberOfTheDay <= 0 || numberOfTheDay > 7) {
            System.out.println("Invalid day!");
        } else {
            System.out.println(daysAsString[numberOfTheDay - 1]);



        }
    }
}
