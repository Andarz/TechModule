package ObjectAndClassesLab;

import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);
    }
}
