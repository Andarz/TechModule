package ObjectAndClassesExcercise.AdvertismentMessage;

public class Messsage {
    public static void main(String[] args) {
    }
}
