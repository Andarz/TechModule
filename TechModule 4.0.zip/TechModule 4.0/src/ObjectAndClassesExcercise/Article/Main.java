package ObjectAndClassesExcercise.Article;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String[] data = keys.nextLine().split(", ");
        int n = Integer.parseInt(keys.nextLine());

        for (int i = 0; i < n; i++) {
            String[] input = keys.nextLine().split(": ");
            String command = input[0];

        }
    }
}
