package ObjectAndClassesExcercise.OpinionPoll;

public class Main {
    public static void main(String[] args) {
    }
}
