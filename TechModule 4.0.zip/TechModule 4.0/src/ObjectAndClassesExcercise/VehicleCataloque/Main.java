package ObjectAndClassesExcercise.VehicleCataloque;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        String input = "";

        List<Vehicle> vehicles = new ArrayList<>();
        while(!"End".equals(input = keys.nextLine())) {
            String[] vehicleData = input.split(" ");
            Vehicle vehicle = new Vehicle(
                    vehicleData[0],
                    vehicleData[1],
                    vehicleData[2],
                    Integer.parseInt(vehicleData[3])
            );
        }
    }
}
