import java.util.Arrays;
import java.util.Scanner;

public class ArraysExercise {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int n = Integer.parseInt(keys.nextLine());
        int[] num = new int[n];

        int sum = 0;

        for (int i = 0; i < n; i++) {
            num[i] = Integer.parseInt(keys.nextLine());
            sum += num[i];
            System.out.print(num[i] + " ");

        }
        System.out.println("");
        System.out.println(sum);
    }
}
