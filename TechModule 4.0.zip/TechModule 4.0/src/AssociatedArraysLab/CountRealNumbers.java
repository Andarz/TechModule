package AssociatedArraysLab;

import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class CountRealNumbers {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        double[] nums = Arrays.stream(keys.nextLine().split("\\s+"))
                .mapToDouble(Double::parseDouble).toArray();

        Map<Double, Integer> myMap = new TreeMap<>();
        for (double num : nums) {
            myMap.putIfAbsent(num, 0);
        }
    }
}
