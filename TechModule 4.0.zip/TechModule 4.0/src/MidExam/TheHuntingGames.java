package MidExam;

import java.util.Scanner;

public class TheHuntingGames {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        int days = Integer.parseInt(keys.nextLine());
        int players = Integer.parseInt(keys.nextLine());
        double energy = Double.parseDouble(keys.nextLine());
        double water = Double.parseDouble(keys.nextLine());
        double food = Double.parseDouble(keys.nextLine());

        double totalFood = food * days * players;
        double totalWater = water * days * players;

        for (int day = 1; day <= days; day++) {
            double energyLoss = Double.parseDouble(keys.nextLine());
            if (energyLoss > energy) {
                energy -= energyLoss;
                break;
            }
            energy -= energyLoss;

            if (day % 2 == 0) {
                energy = energy * 1.05;
                totalWater = (totalWater * 0.7);
            }

            if (day % 3 == 0) {
                totalFood -= totalFood / players;
                energy = energy * 1.10;
            }
        }
        if (energy > 0) {
            System.out.printf("You are ready for the quest. " +
                    "You will be left with - %.2f energy!", energy);
        } else {
            System.out.printf("You will run out of energy. " +
                    "You will be left with %.2f food and %.2f water.", totalFood, totalWater);
        }
    }


}

