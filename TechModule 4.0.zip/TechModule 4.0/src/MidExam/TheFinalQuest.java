package MidExam;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class TheFinalQuest {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<String> line = Arrays.stream(keys.nextLine().split("\\s+"))
                .collect(Collectors.toList());

        String input = keys.nextLine();

        while (!input.equals("Stop")) {
            String[] tokens = input.split("\\s+");
            String command = tokens[0];

            switch (command) {
                case "Delete":
                    int index = Integer.parseInt(tokens[1]);
                    int indexToDelete = Integer.parseInt(tokens[1]) + 1;

                    if (indexToDelete > 0 && indexToDelete <= line.size() - 1) {
                        line.remove(indexToDelete);
                    }
                    break;
                case "Swap":
                    if (line.contains(tokens[1]) &&
                            line.contains(tokens[2])) {
                        Collections.swap(line, line.indexOf(tokens[1]), line.indexOf(tokens[2]));
                    }
                    break;
                case "Put":
                    int indexToPut = Integer.parseInt(tokens[2]) - 1;

                    if (indexToPut <=line.size() && indexToPut > 0) {
                        line.add(indexToPut, tokens[1]);
                    }
                    break;
                case "Sort":
                    line.sort(Collections.reverseOrder());
                    break;
                case "Replace":
                    String word1 = tokens[1];
                    String word2 = tokens[2];
                    if (line.contains(word2)) {
                        line.set(line.indexOf(word2), word1);
                    }
                    break;
            }

            input = keys.nextLine();
        }

        System.out.println(String.join(" ", line));
    }
}
