package MidExam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SeizeTheFire {
    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);

        List<String> fireCells = Arrays.stream(keys.nextLine().split("#"))
                .collect(Collectors.toList());

        int totalWater = Integer.parseInt(keys.nextLine());

        double totalEffort = 0;
        int totalFire = 0;
        List<Integer> putCells = new ArrayList<>();

        for (int cell = 0; cell < fireCells.size(); cell++) {

            if (totalWater <= 0) {
                break;
            } else {

                String singleCell = fireCells.get(cell);

                String[] cellProp = singleCell.split(" = ");
                String fireType = cellProp[0];
                int neededWater = Integer.parseInt(cellProp[1]);

                if (totalWater < neededWater) {
                    continue;
                }

                switch (fireType) {
                    case "High":
                        if (neededWater >= 81 && neededWater <= 125) {
                            totalWater -= neededWater;
                            totalEffort += (neededWater * 0.25);
                            totalFire += neededWater;
                            putCells.add(neededWater);
                            neededWater = 0;

                        }
                        break;
                    case "Medium":
                        if (neededWater >= 51 && neededWater <= 80) {
                            totalWater -= neededWater;
                            totalEffort += (neededWater * 0.25);
                            totalFire += neededWater;
                            putCells.add(neededWater);
                            neededWater = 0;

                        }
                        break;
                    case "Low":
                        if (neededWater >= 1 && neededWater <= 50) {
                            totalWater -= neededWater;
                            totalEffort += (neededWater * 0.25);
                            totalFire += neededWater;
                            putCells.add(neededWater);
                            neededWater = 0;

                        }
                        break;
                }
            }
        }

        System.out.println("Cells:");
        for (Integer putCell : putCells) {
            System.out.printf("- %d%n", putCell);
        }

        System.out.printf("Effort: %.2f%n", totalEffort);
        System.out.printf("Total Fire: %d", totalFire);

    }
}
